/**
 * Created by zongjuan.wang on 2016/6/29.
 */

$(document).ready(function(){
    var headImg=new Array("head01.jpg","head02.jpg","head03.jpg");
    var uName=new Array("柠檬","柚子","海棠");
    $("#send").click(function(){
        //判断当前输入框中是否有内容
        if($(".chatText").val().length>0){
        	//获取当前聊天内容
            var str=$(".chatBody").html();      
            //随机获取头像和昵称
            var iNum=Math.floor(Math.random()*2);  
            //设置头像
            var headStr="<div><img src=images/"+headImg[iNum]+"></div>";   
            //设置昵称
            var userName="<p>"+uName[iNum]+"</p>";                
            //获取并设置当前输入的内容
            var chatStr="<div>"+$(".chatText").val()+"</div>";    
            //当前聊天的头像、昵称和内容
            var currentStr="<section>"+headStr+userName+chatStr+"</section>"; 
            //当前输入的跳入介面内
            $(".chatBody").html(str+currentStr);
            $(".chatBody section div:last").addClass("chatContent");
            //清除文本框中的内容
            $(".chatText").val("");
        }
    });
})

