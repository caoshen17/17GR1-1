$(document).ready(function(){
	$(".box dl").hover(function(){
		$(this).addClass("hoverstyle");
	},function(){
		$(this).removeClass("hoverstyle");
		
	});	
});
