
$(document).ready(function(){
    $(".bbs header span").click(function(){
        $(".bbs .post").show();
    });
    var tou=new Array("tou01.jpg","tou02.jpg","tou03.jpg","tou04.jpg");
    $(".post .btn").click(function(){
    	//创建一个新的li节点元素
        var $newLi=$("<li></li>");
        //随机获取头像
        var iNum=Math.floor(Math.random()*4); 
        //创建头像节点
        var $touImg=$("<div><img src=images/"+tou[iNum]+"></div>");  
        //设置标题节点
        var $title=$("<h1>"+$(".title").val()+"</h1>");
        //创建一个新的p节点元素
        var newP=$("<p></p>");  
        var myDate=new Date();
        var currentDate=myDate.getFullYear()+
        "-"+parseInt(myDate.getMonth()+1)+
        "-"+myDate.getDate()+" "+
        myDate.getHours()+":"
        +myDate.getMinutes();
        //在p节点中插入版块；
        $(newP).append("<span>版块："+$(".post select").val()+"</span>");  
        //在p节点中插入发布时间；
        $(newP).append("<span>发表时间："+currentDate+"</span>");     
        //插入头像
        $($newLi).append($touImg);  
        //插入标题
        $($newLi).append($title);   
        //插入版块、时间内容
        $($newLi).append(newP);   
        $(".bbs section ul").prepend($newLi);

        $(".post .content").val("");
        $(".post .title").val("");
        $(".post").hide();


    });
})