package org.news.service;

public interface NewsService {
 public int delete(int id);
 
}
