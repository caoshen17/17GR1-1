package org.news.service;

import org.news.entity.Topic;

public interface TopService {
	//ɾ���ж�
	public int delPanDuan(int id);
	//�ж��޸�
	public int updatePanDuan(Topic top);
}
